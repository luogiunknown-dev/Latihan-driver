Latihan Sopir - proyek Android (WebView)
1. Buka folder ini di Android Studio (File > Open).
2. Tunggu Gradle sync selesai (butuh internet).
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK ada di app/build/outputs/apk/debug/app-debug.apk
Atau colok HP (USB debugging aktif) lalu tekan Run.
Konten tutorial: app/src/main/assets/index.html
